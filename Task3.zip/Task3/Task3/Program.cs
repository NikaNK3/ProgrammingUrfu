﻿Dictionary<string, string> dictionary = new Dictionary<string, string>();

Console.WriteLine("Сколько записей хотите добавить?");
int count = int.Parse(Console.ReadLine());

//add
for (int i = 0; i < count; i++)
{
    Console.WriteLine("Введите имя: ");
    string name = Console.ReadLine()?.Trim().ToLower();
    Console.WriteLine("Введите номер: ");
    string number = Console.ReadLine()?.Trim();

    if (string.IsNullOrWhiteSpace(name)) { Console.WriteLine("Пустое имя"); return; }
    if (string.IsNullOrWhiteSpace(number)) { Console.WriteLine("Пустое номер"); return; }

    if (!dictionary.TryAdd(name, number))
    {
        Console.WriteLine("Запись с таким именем уже существует. Данные не изменены");
    }
}

//find
Console.WriteLine("\nВведите имя, по которому искать записи: ");
string find = Console.ReadLine()?.Trim().ToLower();

if (string.IsNullOrWhiteSpace(find)) { Console.WriteLine("Пустое имя"); }

Console.WriteLine($"\nРезультаты поиска: \nИмя: {find}, номер: {dictionary[find]}");

//list
if (count == 0) { Console.WriteLine("\nВ словаре нет записей"); }
else
{
    Console.WriteLine("\nВесь словарь: ");
    foreach (var (who, num) in dictionary) { Console.WriteLine($"Имя: {who}, номер: {num}"); }
}







